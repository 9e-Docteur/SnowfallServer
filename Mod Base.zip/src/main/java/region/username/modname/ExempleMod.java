package region.username.modname;

import be.ninedocteur.apare.api.mod.ApareMod;
import be.ninedocteur.apare.api.mod.Mod;
import be.ninedocteur.apare.api.mod.ModSide;

@Mod(value = ExempleMod.class, modSide = ModSide.BOTH)
public class ExempleMod extends ApareMod {

    public ExempleMod() {
        super("modName", "modid", "modVersion", "YourName", "Your Credit(s)", "Your Mod Description");
    }

    @Override
    public void init() {

    }
}
